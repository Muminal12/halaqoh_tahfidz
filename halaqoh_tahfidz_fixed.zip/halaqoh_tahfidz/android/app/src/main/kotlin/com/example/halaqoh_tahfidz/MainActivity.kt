package com.example.halaqoh_tahfidz
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
