import 'package:hive/hive.dart';

/// Model data Setoran (Ziyadah & Murajaah) milik seorang santri.
class Setoran extends HiveObject {
  String id;
  DateTime tanggal;
  String santriId;

  // Ziyadah (hafalan baru) - boleh kosong (null)
  String? ziyadahDariSurah;
  int? ziyadahDariAyat;
  String? ziyadahSampaiSurah;
  int? ziyadahSampaiAyat;

  // Murajaah (mengulang hafalan) - boleh kosong (null)
  String? murajaahDariSurah;
  int? murajaahDariAyat;
  String? murajaahSampaiSurah;
  int? murajaahSampaiAyat;

  Setoran({
    required this.id,
    required this.tanggal,
    required this.santriId,
    this.ziyadahDariSurah,
    this.ziyadahDariAyat,
    this.ziyadahSampaiSurah,
    this.ziyadahSampaiAyat,
    this.murajaahDariSurah,
    this.murajaahDariAyat,
    this.murajaahSampaiSurah,
    this.murajaahSampaiAyat,
  });

  bool get adaZiyadah => ziyadahDariSurah != null && ziyadahDariSurah!.isNotEmpty;
  bool get adaMurajaah => murajaahDariSurah != null && murajaahDariSurah!.isNotEmpty;

  String get teksZiyadah {
    if (!adaZiyadah) return '-';
    if (ziyadahDariSurah == ziyadahSampaiSurah) {
      return '$ziyadahDariSurah ayat $ziyadahDariAyat–$ziyadahSampaiAyat';
    }
    return '$ziyadahDariSurah:$ziyadahDariAyat – $ziyadahSampaiSurah:$ziyadahSampaiAyat';
  }

  String get teksMurajaah {
    if (!adaMurajaah) return '-';
    if (murajaahDariSurah == murajaahSampaiSurah) {
      return '$murajaahDariSurah ayat $murajaahDariAyat–$murajaahSampaiAyat';
    }
    return '$murajaahDariSurah:$murajaahDariAyat – $murajaahSampaiSurah:$murajaahSampaiAyat';
  }
}

/// Adapter Hive manual untuk Setoran (typeId: 1).
class SetoranAdapter extends TypeAdapter<Setoran> {
  @override
  final int typeId = 1;

  @override
  Setoran read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Setoran(
      id: fields[0] as String,
      tanggal: fields[1] as DateTime,
      santriId: fields[2] as String,
      ziyadahDariSurah: fields[3] as String?,
      ziyadahDariAyat: fields[4] as int?,
      ziyadahSampaiSurah: fields[5] as String?,
      ziyadahSampaiAyat: fields[6] as int?,
      murajaahDariSurah: fields[7] as String?,
      murajaahDariAyat: fields[8] as int?,
      murajaahSampaiSurah: fields[9] as String?,
      murajaahSampaiAyat: fields[10] as int?,
    );
  }

  @override
  void write(BinaryWriter writer, Setoran obj) {
    writer
      ..writeByte(11)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.tanggal)
      ..writeByte(2)
      ..write(obj.santriId)
      ..writeByte(3)
      ..write(obj.ziyadahDariSurah)
      ..writeByte(4)
      ..write(obj.ziyadahDariAyat)
      ..writeByte(5)
      ..write(obj.ziyadahSampaiSurah)
      ..writeByte(6)
      ..write(obj.ziyadahSampaiAyat)
      ..writeByte(7)
      ..write(obj.murajaahDariSurah)
      ..writeByte(8)
      ..write(obj.murajaahDariAyat)
      ..writeByte(9)
      ..write(obj.murajaahSampaiSurah)
      ..writeByte(10)
      ..write(obj.murajaahSampaiAyat);
  }
}
