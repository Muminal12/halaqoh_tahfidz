/// Model data Surah (bukan disimpan di Hive, hanya data statis referensi).
class Surah {
  final int nomor;
  final String nama;
  final int jumlahAyat;

  const Surah({
    required this.nomor,
    required this.nama,
    required this.jumlahAyat,
  });

  /// Label untuk dropdown, contoh: "01 — Al-Fatihah"
  String get label {
    final nomorStr = nomor.toString().padLeft(2, '0');
    return '$nomorStr — $nama';
  }

  @override
  String toString() => nama;
}
