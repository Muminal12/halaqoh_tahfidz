import 'package:hive/hive.dart';

/// Model data Santri (peserta halaqoh tahfidz).
class Santri extends HiveObject {
  String id;
  String nama;

  Santri({required this.id, required this.nama});
}

/// Adapter Hive manual untuk Santri (typeId: 0).
class SantriAdapter extends TypeAdapter<Santri> {
  @override
  final int typeId = 0;

  @override
  Santri read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Santri(
      id: fields[0] as String,
      nama: fields[1] as String,
    );
  }

  @override
  void write(BinaryWriter writer, Santri obj) {
    writer
      ..writeByte(2)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.nama);
  }
}
