import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/setoran.dart';
import '../services/database_service.dart';
import '../theme.dart';

/// Halaman Riwayat Setoran: daftar semua setoran dengan cari & filter.
class RiwayatSetoranScreen extends StatefulWidget {
  const RiwayatSetoranScreen({super.key});

  @override
  State<RiwayatSetoranScreen> createState() => _RiwayatSetoranScreenState();
}

class _RiwayatSetoranScreenState extends State<RiwayatSetoranScreen> {
  final _db = DatabaseService.instance;
  String _keyword = '';
  DateTime? _filterTanggal;

  List<Setoran> get _data {
    var list = _db.semuaSetoran();
    if (_filterTanggal != null) {
      list = list
          .where((s) =>
              s.tanggal.year == _filterTanggal!.year &&
              s.tanggal.month == _filterTanggal!.month &&
              s.tanggal.day == _filterTanggal!.day)
          .toList();
    }
    if (_keyword.isNotEmpty) {
      list = list.where((s) {
        final santri = _db.santriById(s.santriId);
        return (santri?.nama.toLowerCase() ?? '').contains(_keyword.toLowerCase());
      }).toList();
    }
    return list;
  }

  Future<void> _pilihFilterTanggal() async {
    final hasil = await showDatePicker(
      context: context,
      initialDate: _filterTanggal ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    setState(() => _filterTanggal = hasil);
  }

  Future<void> _hapus(Setoran s) async {
    final konfirmasi = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Hapus Setoran'),
        content: const Text('Yakin ingin menghapus catatan setoran ini?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (konfirmasi == true) {
      await _db.hapusSetoran(s);
      setState(() {});
    }
  }

  Future<void> _editDialog(Setoran s) async {
    // Edit sederhana: hanya bisa mengubah tanggal untuk versi awal.
    final hasil = await showDatePicker(
      context: context,
      initialDate: s.tanggal,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (hasil != null) {
      s.tanggal = hasil;
      await s.save();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = _data;
    return Scaffold(
      appBar: AppBar(title: const Text('Riwayat Setoran')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _keyword = v),
              decoration: const InputDecoration(hintText: 'Cari nama santri...', prefixIcon: Icon(Icons.search)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _pilihFilterTanggal,
                    icon: const Icon(Icons.date_range, size: 18),
                    label: Text(
                      _filterTanggal == null
                          ? 'Filter Tanggal'
                          : DateFormat('dd MMM yyyy', 'id_ID').format(_filterTanggal!),
                    ),
                  ),
                ),
                if (_filterTanggal != null)
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => setState(() => _filterTanggal = null),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: data.isEmpty
                ? const Center(child: Text('Belum ada riwayat setoran', style: TextStyle(color: AppColors.abuTeks)))
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: data.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, i) {
                      final s = data[i];
                      final santri = _db.santriById(s.santriId);
                      return Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.latarKartu,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    DateFormat('dd MMMM yyyy', 'id_ID').format(s.tanggal),
                                    style: const TextStyle(fontSize: 12, color: AppColors.abuTeks),
                                  ),
                                ),
                                IconButton(
                                  visualDensity: VisualDensity.compact,
                                  icon: const Icon(Icons.edit_outlined, size: 18, color: AppColors.hijauUtama),
                                  onPressed: () => _editDialog(s),
                                ),
                                IconButton(
                                  visualDensity: VisualDensity.compact,
                                  icon: const Icon(Icons.delete_outline, size: 18, color: Colors.redAccent),
                                  onPressed: () => _hapus(s),
                                ),
                              ],
                            ),
                            Text(santri?.nama ?? 'Santri tidak ditemukan',
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            const SizedBox(height: 8),
                            if (s.adaZiyadah)
                              _baris('📗 Ziyadah', s.teksZiyadah),
                            if (s.adaMurajaah)
                              _baris('🔄 Murajaah', s.teksMurajaah),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _baris(String label, String isi) {
    return Padding(
      padding: const EdgeInsets.only(top: 2),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 13, color: Colors.black87),
          children: [
            TextSpan(text: '$label: ', style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.hijauUtama)),
            TextSpan(text: isi),
          ],
        ),
      ),
    );
  }
}
