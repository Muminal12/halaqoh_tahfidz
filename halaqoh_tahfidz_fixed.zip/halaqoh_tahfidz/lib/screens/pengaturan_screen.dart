import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/export_service.dart';
import '../theme.dart';

/// Halaman Pengaturan: Backup & Restore data, Export, info aplikasi.
class PengaturanScreen extends StatefulWidget {
  const PengaturanScreen({super.key});

  @override
  State<PengaturanScreen> createState() => _PengaturanScreenState();
}

class _PengaturanScreenState extends State<PengaturanScreen> {
  bool _memproses = false;

  Future<void> _backup() async {
    setState(() => _memproses = true);
    try {
      await ExportService.backupDanBagikan();
      _pesan('Backup berhasil dibuat.');
    } catch (e) {
      _pesan('Gagal membuat backup: $e', error: true);
    } finally {
      if (mounted) setState(() => _memproses = false);
    }
  }

  Future<void> _restore() async {
    final konfirmasi = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Restore Data'),
        content: const Text(
          'Restore akan MENGGANTI seluruh data santri & setoran saat ini dengan data dari file backup. Lanjutkan?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lanjutkan')),
        ],
      ),
    );
    if (konfirmasi != true) return;

    setState(() => _memproses = true);
    try {
      final hasil = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
      if (hasil == null || hasil.files.single.path == null) {
        setState(() => _memproses = false);
        return;
      }
      final file = File(hasil.files.single.path!);
      await ExportService.restoreDariFile(file);
      _pesan('Restore data berhasil.');
      setState(() {});
    } catch (e) {
      _pesan('Gagal melakukan restore: $e', error: true);
    } finally {
      if (mounted) setState(() => _memproses = false);
    }
  }

  Future<void> _exportCsv() async {
    setState(() => _memproses = true);
    try {
      await ExportService.exportCsv(DatabaseService.instance.semuaSetoran());
    } finally {
      if (mounted) setState(() => _memproses = false);
    }
  }

  void _pesan(String teks, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(teks),
        backgroundColor: error ? Colors.redAccent : AppColors.hijauUtama,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final db = DatabaseService.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _kartuMenu(
            icon: Icons.backup_outlined,
            judul: 'Backup Data',
            subjudul: 'Simpan seluruh data santri & setoran ke file',
            onTap: _memproses ? null : _backup,
          ),
          _kartuMenu(
            icon: Icons.restore_outlined,
            judul: 'Restore Data',
            subjudul: 'Pulihkan data dari file backup (.json)',
            onTap: _memproses ? null : _restore,
          ),
          _kartuMenu(
            icon: Icons.table_chart_outlined,
            judul: 'Export Excel/CSV',
            subjudul: 'Ekspor seluruh riwayat setoran ke CSV',
            onTap: _memproses ? null : _exportCsv,
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: AppColors.hijauMuda, borderRadius: BorderRadius.circular(16)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('📖 HALAQOH TAHFIDZ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.hijauTua)),
                const SizedBox(height: 4),
                const Text("Ustadz Al Mu'min", style: TextStyle(color: AppColors.hijauUtama)),
                const SizedBox(height: 10),
                Text('Total Santri: ${db.semuaSantri().length}', style: const TextStyle(fontSize: 12, color: AppColors.abuTeks)),
                Text('Total Riwayat Setoran: ${db.semuaSetoran().length}', style: const TextStyle(fontSize: 12, color: AppColors.abuTeks)),
                const SizedBox(height: 6),
                const Text('Versi Aplikasi: 1.0.0', style: TextStyle(fontSize: 12, color: AppColors.abuTeks)),
                const Text('Berjalan sepenuhnya offline.', style: TextStyle(fontSize: 12, color: AppColors.abuTeks)),
              ],
            ),
          ),
          if (_memproses)
            const Padding(
              padding: EdgeInsets.only(top: 20),
              child: Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }

  Widget _kartuMenu({
    required IconData icon,
    required String judul,
    required String subjudul,
    required VoidCallback? onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: AppColors.latarKartu, borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: AppColors.hijauMuda, child: Icon(icon, color: AppColors.hijauUtama)),
        title: Text(judul, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subjudul, style: const TextStyle(fontSize: 12)),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
