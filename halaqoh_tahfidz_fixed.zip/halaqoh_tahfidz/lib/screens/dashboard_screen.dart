import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/database_service.dart';
import '../theme.dart';
import '../widgets/stat_card.dart';

/// Halaman utama (Beranda) dengan ringkasan statistik halaqoh.
class DashboardScreen extends StatefulWidget {
  final VoidCallback onTambahSetoran;
  const DashboardScreen({super.key, required this.onTambahSetoran});

  @override
  State<DashboardScreen> createState() => DashboardScreenState();
}

class DashboardScreenState extends State<DashboardScreen> {
  final _db = DatabaseService.instance;

  int totalSantri = 0;
  int ziyadahHariIni = 0;
  int murajaahHariIni = 0;
  int setoranMingguIni = 0;

  @override
  void initState() {
    super.initState();
    muatUlang();
  }

  void muatUlang() {
    final semuaSantri = _db.semuaSantri();
    final hariIni = DateTime.now();
    final setoranHariIni = _db.setoranPadaTanggal(hariIni);

    final awalMinggu = hariIni.subtract(Duration(days: hariIni.weekday - 1));
    final akhirMinggu = awalMinggu.add(const Duration(days: 6));
    final setoranMinggu = _db.setoranDalamRentang(awalMinggu, akhirMinggu);

    setState(() {
      totalSantri = semuaSantri.length;
      ziyadahHariIni = setoranHariIni.where((s) => s.adaZiyadah).length;
      murajaahHariIni = setoranHariIni.where((s) => s.adaMurajaah).length;
      setoranMingguIni = setoranMinggu.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    final tanggalHariIni = DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(DateTime.now());

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async => muatUlang(),
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              // Header Islami
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.hijauUtama, AppColors.hijauTua],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 28),
                        ),
                        const SizedBox(width: 14),
                        const Expanded(
                          child: Text(
                            'HALAQOH TAHFIDZ',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const Padding(
                      padding: EdgeInsets.only(left: 54),
                      child: Text(
                        "Ustadz Al Mu'min",
                        style: TextStyle(color: AppColors.emas, fontSize: 15, fontWeight: FontWeight.w600),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      tanggalHariIni,
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Statistik
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.4,
                children: [
                  StatCard(emoji: '👥', label: 'Total Santri', value: '$totalSantri'),
                  StatCard(emoji: '📗', label: 'Ziyadah Hari Ini', value: '$ziyadahHariIni'),
                  StatCard(emoji: '🔄', label: 'Murajaah Hari Ini', value: '$murajaahHariIni'),
                  StatCard(emoji: '📊', label: 'Setoran Minggu Ini', value: '$setoranMingguIni'),
                ],
              ),
              const SizedBox(height: 20),

              ElevatedButton.icon(
                onPressed: widget.onTambahSetoran,
                icon: const Icon(Icons.add_rounded),
                label: const Text('Input Setoran'),
                style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 54)),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}
