import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/santri.dart';
import '../services/database_service.dart';
import '../services/surah_data.dart';
import '../theme.dart';
import 'riwayat_setoran_screen.dart';

/// Halaman Input Setoran: mencatat Ziyadah & Murajaah harian santri.
class InputSetoranScreen extends StatefulWidget {
  final VoidCallback onSelesai;
  const InputSetoranScreen({super.key, required this.onSelesai});

  @override
  State<InputSetoranScreen> createState() => _InputSetoranScreenState();
}

class _InputSetoranScreenState extends State<InputSetoranScreen> {
  final _formKey = GlobalKey<FormState>();
  final _db = DatabaseService.instance;

  DateTime _tanggal = DateTime.now();
  Santri? _santriTerpilih;

  // Ziyadah
  String? _zDariSurah, _zSampaiSurah;
  final _zDariAyatCtrl = TextEditingController();
  final _zSampaiAyatCtrl = TextEditingController();

  // Murajaah
  String? _mDariSurah, _mSampaiSurah;
  final _mDariAyatCtrl = TextEditingController();
  final _mSampaiAyatCtrl = TextEditingController();

  @override
  void dispose() {
    _zDariAyatCtrl.dispose();
    _zSampaiAyatCtrl.dispose();
    _mDariAyatCtrl.dispose();
    _mSampaiAyatCtrl.dispose();
    super.dispose();
  }

  Future<void> _pilihTanggal() async {
    final hasil = await showDatePicker(
      context: context,
      initialDate: _tanggal,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (hasil != null) setState(() => _tanggal = hasil);
  }

  int? _parseInt(String s) => s.trim().isEmpty ? null : int.tryParse(s.trim());

  String? _validasiZiyadahMurajaah() {
    final adaZ = _zDariSurah != null || _zSampaiSurah != null;
    final adaM = _mDariSurah != null || _mSampaiSurah != null;

    if (!adaZ && !adaM) {
      return 'Isi minimal salah satu: Ziyadah atau Murajaah.';
    }

    if (adaZ) {
      if (_zDariSurah == null || _zSampaiSurah == null) {
        return 'Lengkapi Surah Ziyadah (Dari & Sampai).';
      }
      final errDari = SurahData.validasiAyat(_zDariSurah, _parseInt(_zDariAyatCtrl.text));
      if (errDari != null) return 'Ziyadah: $errDari';
      final errSampai = SurahData.validasiAyat(_zSampaiSurah, _parseInt(_zSampaiAyatCtrl.text));
      if (errSampai != null) return 'Ziyadah: $errSampai';
    }

    if (adaM) {
      if (_mDariSurah == null || _mSampaiSurah == null) {
        return 'Lengkapi Surah Murajaah (Dari & Sampai).';
      }
      final errDari = SurahData.validasiAyat(_mDariSurah, _parseInt(_mDariAyatCtrl.text));
      if (errDari != null) return 'Murajaah: $errDari';
      final errSampai = SurahData.validasiAyat(_mSampaiSurah, _parseInt(_mSampaiAyatCtrl.text));
      if (errSampai != null) return 'Murajaah: $errSampai';
    }
    return null;
  }

  Future<void> _simpan() async {
    if (!_formKey.currentState!.validate()) return;
    if (_santriTerpilih == null) {
      _tampilkanPesan('Pilih nama santri terlebih dahulu.', error: true);
      return;
    }
    final errValidasi = _validasiZiyadahMurajaah();
    if (errValidasi != null) {
      _tampilkanPesan(errValidasi, error: true);
      return;
    }

    await _db.tambahSetoran(
      tanggal: _tanggal,
      santriId: _santriTerpilih!.id,
      ziyadahDariSurah: _zDariSurah,
      ziyadahDariAyat: _parseInt(_zDariAyatCtrl.text),
      ziyadahSampaiSurah: _zSampaiSurah,
      ziyadahSampaiAyat: _parseInt(_zSampaiAyatCtrl.text),
      murajaahDariSurah: _mDariSurah,
      murajaahDariAyat: _parseInt(_mDariAyatCtrl.text),
      murajaahSampaiSurah: _mSampaiSurah,
      murajaahSampaiAyat: _parseInt(_mSampaiAyatCtrl.text),
    );

    _tampilkanPesan('Setoran berhasil disimpan');
    _resetForm();
    widget.onSelesai();
  }

  void _resetForm() {
    setState(() {
      _tanggal = DateTime.now();
      _santriTerpilih = null;
      _zDariSurah = null;
      _zSampaiSurah = null;
      _mDariSurah = null;
      _mSampaiSurah = null;
      _zDariAyatCtrl.clear();
      _zSampaiAyatCtrl.clear();
      _mDariAyatCtrl.clear();
      _mSampaiAyatCtrl.clear();
    });
  }

  void _tampilkanPesan(String pesan, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(pesan),
        backgroundColor: error ? Colors.redAccent : AppColors.hijauUtama,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final daftarSantri = _db.semuaSantri();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Input Setoran'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history_rounded),
            tooltip: 'Riwayat Setoran',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const RiwayatSetoranScreen()),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              _judulSeksi('📖 Input Setoran'),
              const SizedBox(height: 12),
              _kartu(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Informasi Umum', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    InkWell(
                      onTap: _pilihTanggal,
                      child: InputDecorator(
                        decoration: const InputDecoration(labelText: 'Tanggal', suffixIcon: Icon(Icons.calendar_today_outlined)),
                        child: Text(DateFormat('dd MMMM yyyy', 'id_ID').format(_tanggal)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<Santri>(
                      value: _santriTerpilih,
                      decoration: const InputDecoration(labelText: 'Nama Santri'),
                      isExpanded: true,
                      items: daftarSantri
                          .map((s) => DropdownMenuItem(value: s, child: Text(s.nama)))
                          .toList(),
                      onChanged: (v) => setState(() => _santriTerpilih = v),
                      validator: (v) => v == null ? 'Pilih santri' : null,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              _judulSeksi('📗 ZIYADAH'),
              const SizedBox(height: 12),
              _kartu(
                child: _formSurahRentang(
                  dariSurah: _zDariSurah,
                  sampaiSurah: _zSampaiSurah,
                  dariAyatCtrl: _zDariAyatCtrl,
                  sampaiAyatCtrl: _zSampaiAyatCtrl,
                  onDariSurah: (v) => setState(() => _zDariSurah = v),
                  onSampaiSurah: (v) => setState(() => _zSampaiSurah = v),
                ),
              ),
              if (_zDariSurah != null && _zSampaiSurah != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8, left: 4),
                  child: Text(
                    'Hasil: $_zDariSurah ayat ${_zDariAyatCtrl.text.isEmpty ? '?' : _zDariAyatCtrl.text}–${_zSampaiAyatCtrl.text.isEmpty ? '?' : _zSampaiAyatCtrl.text}',
                    style: const TextStyle(color: AppColors.hijauUtama, fontWeight: FontWeight.w600),
                  ),
                ),
              const SizedBox(height: 20),

              _judulSeksi('🔄 MURAJAAH'),
              const SizedBox(height: 12),
              _kartu(
                child: _formSurahRentang(
                  dariSurah: _mDariSurah,
                  sampaiSurah: _mSampaiSurah,
                  dariAyatCtrl: _mDariAyatCtrl,
                  sampaiAyatCtrl: _mSampaiAyatCtrl,
                  onDariSurah: (v) => setState(() => _mDariSurah = v),
                  onSampaiSurah: (v) => setState(() => _mSampaiSurah = v),
                ),
              ),
              if (_mDariSurah != null && _mSampaiSurah != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8, left: 4),
                  child: Text(
                    'Hasil: $_mDariSurah ayat ${_mDariAyatCtrl.text.isEmpty ? '?' : _mDariAyatCtrl.text}–${_mSampaiAyatCtrl.text.isEmpty ? '?' : _mSampaiAyatCtrl.text}',
                    style: const TextStyle(color: AppColors.hijauUtama, fontWeight: FontWeight.w600),
                  ),
                ),
              const SizedBox(height: 8),
              const Text(
                'Catatan: Ziyadah dan Murajaah boleh salah satunya dikosongkan.',
                style: TextStyle(fontSize: 12, color: AppColors.abuTeks, fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 24),

              ElevatedButton.icon(
                onPressed: _simpan,
                icon: const Icon(Icons.save_rounded),
                label: const Text('SIMPAN SETORAN'),
                style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 56)),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _judulSeksi(String teks) => Text(
        teks,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.hijauTua),
      );

  Widget _kartu({required Widget child}) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.latarKartu,
          borderRadius: BorderRadius.circular(16),
        ),
        child: child,
      );

  Widget _formSurahRentang({
    required String? dariSurah,
    required String? sampaiSurah,
    required TextEditingController dariAyatCtrl,
    required TextEditingController sampaiAyatCtrl,
    required ValueChanged<String?> onDariSurah,
    required ValueChanged<String?> onSampaiSurah,
  }) {
    return Column(
      children: [
        _dropdownSurah(label: 'Dari Surah', value: dariSurah, onChanged: onDariSurah),
        const SizedBox(height: 12),
        TextFormField(
          controller: dariAyatCtrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Dari Ayat'),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 16),
        _dropdownSurah(label: 'Sampai Surah', value: sampaiSurah, onChanged: onSampaiSurah),
        const SizedBox(height: 12),
        TextFormField(
          controller: sampaiAyatCtrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Sampai Ayat'),
          onChanged: (_) => setState(() {}),
        ),
      ],
    );
  }

  Widget _dropdownSurah({
    required String label,
    required String? value,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: SurahData.daftarSurah
          .map((s) => DropdownMenuItem(value: s.nama, child: Text(s.label)))
          .toList(),
      onChanged: onChanged,
    );
  }
}
