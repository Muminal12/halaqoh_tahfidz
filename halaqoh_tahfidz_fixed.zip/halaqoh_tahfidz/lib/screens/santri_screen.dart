import 'package:flutter/material.dart';
import '../models/santri.dart';
import '../services/database_service.dart';
import '../theme.dart';

/// Halaman Data Santri: lihat, cari, tambah, edit, hapus.
class SantriScreen extends StatefulWidget {
  const SantriScreen({super.key});

  @override
  State<SantriScreen> createState() => _SantriScreenState();
}

class _SantriScreenState extends State<SantriScreen> {
  final _db = DatabaseService.instance;
  final _searchCtrl = TextEditingController();
  String _keyword = '';

  List<Santri> get _filtered {
    final semua = _db.semuaSantri();
    if (_keyword.isEmpty) return semua;
    return semua.where((s) => s.nama.toLowerCase().contains(_keyword.toLowerCase())).toList();
  }

  Future<void> _dialogTambahEdit({Santri? santri}) async {
    final ctrl = TextEditingController(text: santri?.nama ?? '');
    final hasilNama = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(santri == null ? 'Tambah Santri' : 'Edit Santri'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Nama Santri'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) Navigator.pop(context, ctrl.text.trim());
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );

    if (hasilNama == null || hasilNama.isEmpty) return;

    if (santri == null) {
      await _db.tambahSantri(hasilNama);
    } else {
      await _db.editSantri(santri, hasilNama);
    }
    setState(() {});
  }

  Future<void> _konfirmasiHapus(Santri santri) async {
    final konfirmasi = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Hapus Santri'),
        content: Text('Yakin ingin menghapus "${santri.nama}"? Seluruh riwayat setorannya juga akan terhapus.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (konfirmasi == true) {
      await _db.hapusSantri(santri);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = _filtered;
    return Scaffold(
      appBar: AppBar(title: const Text('Data Santri')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _dialogTambahEdit(),
        backgroundColor: AppColors.hijauUtama,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (v) => setState(() => _keyword = v),
              decoration: const InputDecoration(
                hintText: 'Cari santri...',
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: data.isEmpty
                ? const Center(child: Text('Belum ada data santri', style: TextStyle(color: AppColors.abuTeks)))
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: data.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) {
                      final s = data[i];
                      return Container(
                        decoration: BoxDecoration(
                          color: AppColors.latarKartu,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: AppColors.hijauMuda,
                            child: Text(
                              s.nama.isNotEmpty ? s.nama[0].toUpperCase() : '?',
                              style: const TextStyle(color: AppColors.hijauUtama, fontWeight: FontWeight.bold),
                            ),
                          ),
                          title: Text(s.nama, style: const TextStyle(fontWeight: FontWeight.w600)),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit_outlined, color: AppColors.hijauUtama),
                                onPressed: () => _dialogTambahEdit(santri: s),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                                onPressed: () => _konfirmasiHapus(s),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
