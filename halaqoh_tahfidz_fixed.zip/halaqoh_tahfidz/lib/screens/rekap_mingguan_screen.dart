import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:screenshot/screenshot.dart';
import '../models/santri.dart';
import '../models/setoran.dart';
import '../services/database_service.dart';
import '../services/export_service.dart';
import '../theme.dart';

/// Halaman Rekap Mingguan: statistik & tabel per santri, plus export PNG/CSV.
class RekapMingguanScreen extends StatefulWidget {
  const RekapMingguanScreen({super.key});

  @override
  State<RekapMingguanScreen> createState() => _RekapMingguanScreenState();
}

class _RekapMingguanScreenState extends State<RekapMingguanScreen> {
  final _db = DatabaseService.instance;
  final _screenshotCtrl = ScreenshotController();
  late DateTime _awalMinggu;
  bool _sedangExport = false;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _awalMinggu = now.subtract(Duration(days: now.weekday - 1));
  }

  DateTime get _akhirMinggu => _awalMinggu.add(const Duration(days: 6));

  void _mingguSebelumnya() => setState(() => _awalMinggu = _awalMinggu.subtract(const Duration(days: 7)));
  void _mingguBerikutnya() => setState(() => _awalMinggu = _awalMinggu.add(const Duration(days: 7)));

  List<Setoran> get _setoranMinggu => _db.setoranDalamRentang(_awalMinggu, _akhirMinggu);

  Map<String, List<Setoran>> get _perSantri {
    final map = <String, List<Setoran>>{};
    for (final s in _setoranMinggu) {
      map.putIfAbsent(s.santriId, () => []).add(s);
    }
    return map;
  }

  Future<void> _tampilkanDetail(Santri santri, List<Setoran> daftar) async {
    final ziyadahList = daftar.where((s) => s.adaZiyadah).map((s) => s.teksZiyadah).toList();
    final murajaahList = daftar.where((s) => s.adaMurajaah).map((s) => s.teksMurajaah).toList();

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(santri.nama, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            const Text('📗 Ziyadah:', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.hijauUtama)),
            if (ziyadahList.isEmpty) const Text('- Tidak ada -'),
            ...ziyadahList.map((t) => Text('• $t')),
            const SizedBox(height: 12),
            const Text('🔄 Murajaah:', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.hijauUtama)),
            if (murajaahList.isEmpty) const Text('- Tidak ada -'),
            ...murajaahList.map((t) => Text('• $t')),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Future<void> _exportPng() async {
    setState(() => _sedangExport = true);
    try {
      final bytes = await _screenshotCtrl.captureFromWidget(
        _widgetLaporanPng(),
        pixelRatio: 2.5,
      );
      final file = await ExportService.simpanBytesGambar(
        bytes,
        'rekap_${DateFormat('yyyyMMdd').format(_awalMinggu)}.png',
      );
      await ExportService.bagikanGambar(file, teks: 'Rekap Mingguan Halaqoh Tahfidz');
    } finally {
      if (mounted) setState(() => _sedangExport = false);
    }
  }

  Widget _widgetLaporanPng() {
    final data = _perSantri;
    return Material(
      child: Container(
        width: 720,
        color: Colors.white,
        padding: const EdgeInsets.all(28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.hijauUtama, AppColors.hijauTua]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  const Text('📖 HALAQOH TAHFIDZ',
                      style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  const Text("USTADZ AL MU'MIN", style: TextStyle(color: AppColors.emas, fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  const Text('REKAP MINGGUAN', style: TextStyle(color: Colors.white, fontSize: 14)),
                  Text(
                    '${DateFormat('dd MMM yyyy', 'id_ID').format(_awalMinggu)} – ${DateFormat('dd MMM yyyy', 'id_ID').format(_akhirMinggu)}',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            ...data.entries.map((entry) {
              final santri = _db.santriById(entry.key);
              final ziyadah = entry.value.where((s) => s.adaZiyadah).map((s) => s.teksZiyadah).join(', ');
              final murajaah = entry.value.where((s) => s.adaMurajaah).map((s) => s.teksMurajaah).join(', ');
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.hijauMuda,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFCDE7D8)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(santri?.nama ?? '-', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    const SizedBox(height: 4),
                    Text('📗 ${ziyadah.isEmpty ? '-' : ziyadah}', style: const TextStyle(fontSize: 12)),
                    Text('🔄 ${murajaah.isEmpty ? '-' : murajaah}', style: const TextStyle(fontSize: 12)),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final data = _perSantri;
    final semuaSantri = _db.semuaSantri();
    final totalSetoran = _setoranMinggu.length;
    final totalZiyadah = _setoranMinggu.where((s) => s.adaZiyadah).length;
    final totalMurajaah = _setoranMinggu.where((s) => s.adaMurajaah).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Rekap Mingguan'),
        actions: [
          IconButton(
            icon: const Icon(Icons.image_outlined),
            tooltip: 'Export Rekap PNG',
            onPressed: _sedangExport ? null : _exportPng,
          ),
          IconButton(
            icon: const Icon(Icons.table_chart_outlined),
            tooltip: 'Export Excel/CSV',
            onPressed: () => ExportService.exportCsv(_db.semuaSetoran()),
          ),
        ],
      ),
      body: Screenshot(
        controller: _screenshotCtrl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                IconButton(icon: const Icon(Icons.chevron_left), onPressed: _mingguSebelumnya),
                Expanded(
                  child: Center(
                    child: Text(
                      'Minggu: ${DateFormat('dd MMM', 'id_ID').format(_awalMinggu)} – ${DateFormat('dd MMM yyyy', 'id_ID').format(_akhirMinggu)}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                IconButton(icon: const Icon(Icons.chevron_right), onPressed: _mingguBerikutnya),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _kotakStat('Total Setoran', '$totalSetoran')),
                const SizedBox(width: 10),
                Expanded(child: _kotakStat('Ziyadah', '$totalZiyadah')),
                const SizedBox(width: 10),
                Expanded(child: _kotakStat('Murajaah', '$totalMurajaah')),
              ],
            ),
            const SizedBox(height: 20),
            const Text('Rincian per Santri', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 10),
            if (semuaSantri.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 30),
                child: Center(child: Text('Belum ada data santri', style: TextStyle(color: AppColors.abuTeks))),
              )
            else
              ...semuaSantri.map((santri) {
                final daftar = data[santri.id] ?? [];
                final ziyadahCount = daftar.where((s) => s.adaZiyadah).length;
                final murajaahCount = daftar.where((s) => s.adaMurajaah).length;
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: AppColors.latarKartu,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: ListTile(
                    onTap: () => _tampilkanDetail(santri, daftar),
                    title: Text(santri.nama, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text('Ziyadah: $ziyadahCount • Murajaah: $murajaahCount'),
                    trailing: Text('${daftar.length}', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.hijauUtama, fontSize: 16)),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _kotakStat(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(color: AppColors.hijauMuda, borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.hijauTua)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(fontSize: 11, color: AppColors.abuTeks)),
        ],
      ),
    );
  }
}
