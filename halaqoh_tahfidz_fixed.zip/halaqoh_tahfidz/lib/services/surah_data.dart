import '../models/surah.dart';

/// Daftar lengkap 114 surah Al-Qur'an beserta jumlah ayatnya.
/// Digunakan untuk dropdown pemilihan surah dan validasi nomor ayat.
class SurahData {
  SurahData._();

  static const List<Surah> daftarSurah = [
    Surah(nomor: 1, nama: "Al-Fatihah", jumlahAyat: 7),
    Surah(nomor: 2, nama: "Al-Baqarah", jumlahAyat: 286),
    Surah(nomor: 3, nama: "Ali 'Imran", jumlahAyat: 200),
    Surah(nomor: 4, nama: "An-Nisa", jumlahAyat: 176),
    Surah(nomor: 5, nama: "Al-Ma'idah", jumlahAyat: 120),
    Surah(nomor: 6, nama: "Al-An'am", jumlahAyat: 165),
    Surah(nomor: 7, nama: "Al-A'raf", jumlahAyat: 206),
    Surah(nomor: 8, nama: "Al-Anfal", jumlahAyat: 75),
    Surah(nomor: 9, nama: "At-Taubah", jumlahAyat: 129),
    Surah(nomor: 10, nama: "Yunus", jumlahAyat: 109),
    Surah(nomor: 11, nama: "Hud", jumlahAyat: 123),
    Surah(nomor: 12, nama: "Yusuf", jumlahAyat: 111),
    Surah(nomor: 13, nama: "Ar-Ra'd", jumlahAyat: 43),
    Surah(nomor: 14, nama: "Ibrahim", jumlahAyat: 52),
    Surah(nomor: 15, nama: "Al-Hijr", jumlahAyat: 99),
    Surah(nomor: 16, nama: "An-Nahl", jumlahAyat: 128),
    Surah(nomor: 17, nama: "Al-Isra", jumlahAyat: 111),
    Surah(nomor: 18, nama: "Al-Kahf", jumlahAyat: 110),
    Surah(nomor: 19, nama: "Maryam", jumlahAyat: 98),
    Surah(nomor: 20, nama: "Ta-Ha", jumlahAyat: 135),
    Surah(nomor: 21, nama: "Al-Anbiya", jumlahAyat: 112),
    Surah(nomor: 22, nama: "Al-Hajj", jumlahAyat: 78),
    Surah(nomor: 23, nama: "Al-Mu'minun", jumlahAyat: 118),
    Surah(nomor: 24, nama: "An-Nur", jumlahAyat: 64),
    Surah(nomor: 25, nama: "Al-Furqan", jumlahAyat: 77),
    Surah(nomor: 26, nama: "Asy-Syu'ara", jumlahAyat: 227),
    Surah(nomor: 27, nama: "An-Naml", jumlahAyat: 93),
    Surah(nomor: 28, nama: "Al-Qasas", jumlahAyat: 88),
    Surah(nomor: 29, nama: "Al-Ankabut", jumlahAyat: 69),
    Surah(nomor: 30, nama: "Ar-Rum", jumlahAyat: 60),
    Surah(nomor: 31, nama: "Luqman", jumlahAyat: 34),
    Surah(nomor: 32, nama: "As-Sajdah", jumlahAyat: 30),
    Surah(nomor: 33, nama: "Al-Ahzab", jumlahAyat: 73),
    Surah(nomor: 34, nama: "Saba", jumlahAyat: 54),
    Surah(nomor: 35, nama: "Fatir", jumlahAyat: 45),
    Surah(nomor: 36, nama: "Ya-Sin", jumlahAyat: 83),
    Surah(nomor: 37, nama: "As-Saffat", jumlahAyat: 182),
    Surah(nomor: 38, nama: "Sad", jumlahAyat: 88),
    Surah(nomor: 39, nama: "Az-Zumar", jumlahAyat: 75),
    Surah(nomor: 40, nama: "Ghafir", jumlahAyat: 85),
    Surah(nomor: 41, nama: "Fussilat", jumlahAyat: 54),
    Surah(nomor: 42, nama: "Asy-Syura", jumlahAyat: 53),
    Surah(nomor: 43, nama: "Az-Zukhruf", jumlahAyat: 89),
    Surah(nomor: 44, nama: "Ad-Dukhan", jumlahAyat: 59),
    Surah(nomor: 45, nama: "Al-Jasiyah", jumlahAyat: 37),
    Surah(nomor: 46, nama: "Al-Ahqaf", jumlahAyat: 35),
    Surah(nomor: 47, nama: "Muhammad", jumlahAyat: 38),
    Surah(nomor: 48, nama: "Al-Fath", jumlahAyat: 29),
    Surah(nomor: 49, nama: "Al-Hujurat", jumlahAyat: 18),
    Surah(nomor: 50, nama: "Qaf", jumlahAyat: 45),
    Surah(nomor: 51, nama: "Az-Zariyat", jumlahAyat: 60),
    Surah(nomor: 52, nama: "At-Tur", jumlahAyat: 49),
    Surah(nomor: 53, nama: "An-Najm", jumlahAyat: 62),
    Surah(nomor: 54, nama: "Al-Qamar", jumlahAyat: 55),
    Surah(nomor: 55, nama: "Ar-Rahman", jumlahAyat: 78),
    Surah(nomor: 56, nama: "Al-Waqi'ah", jumlahAyat: 96),
    Surah(nomor: 57, nama: "Al-Hadid", jumlahAyat: 29),
    Surah(nomor: 58, nama: "Al-Mujadilah", jumlahAyat: 22),
    Surah(nomor: 59, nama: "Al-Hasyr", jumlahAyat: 24),
    Surah(nomor: 60, nama: "Al-Mumtahanah", jumlahAyat: 13),
    Surah(nomor: 61, nama: "As-Saff", jumlahAyat: 14),
    Surah(nomor: 62, nama: "Al-Jumu'ah", jumlahAyat: 11),
    Surah(nomor: 63, nama: "Al-Munafiqun", jumlahAyat: 11),
    Surah(nomor: 64, nama: "At-Tagabun", jumlahAyat: 18),
    Surah(nomor: 65, nama: "At-Talaq", jumlahAyat: 12),
    Surah(nomor: 66, nama: "At-Tahrim", jumlahAyat: 12),
    Surah(nomor: 67, nama: "Al-Mulk", jumlahAyat: 30),
    Surah(nomor: 68, nama: "Al-Qalam", jumlahAyat: 52),
    Surah(nomor: 69, nama: "Al-Haqqah", jumlahAyat: 52),
    Surah(nomor: 70, nama: "Al-Ma'arij", jumlahAyat: 44),
    Surah(nomor: 71, nama: "Nuh", jumlahAyat: 28),
    Surah(nomor: 72, nama: "Al-Jinn", jumlahAyat: 28),
    Surah(nomor: 73, nama: "Al-Muzzammil", jumlahAyat: 20),
    Surah(nomor: 74, nama: "Al-Muddassir", jumlahAyat: 56),
    Surah(nomor: 75, nama: "Al-Qiyamah", jumlahAyat: 40),
    Surah(nomor: 76, nama: "Al-Insan", jumlahAyat: 31),
    Surah(nomor: 77, nama: "Al-Mursalat", jumlahAyat: 50),
    Surah(nomor: 78, nama: "An-Naba", jumlahAyat: 40),
    Surah(nomor: 79, nama: "An-Nazi'at", jumlahAyat: 46),
    Surah(nomor: 80, nama: "'Abasa", jumlahAyat: 42),
    Surah(nomor: 81, nama: "At-Takwir", jumlahAyat: 29),
    Surah(nomor: 82, nama: "Al-Infitar", jumlahAyat: 19),
    Surah(nomor: 83, nama: "Al-Mutaffifin", jumlahAyat: 36),
    Surah(nomor: 84, nama: "Al-Insyiqaq", jumlahAyat: 25),
    Surah(nomor: 85, nama: "Al-Buruj", jumlahAyat: 22),
    Surah(nomor: 86, nama: "At-Tariq", jumlahAyat: 17),
    Surah(nomor: 87, nama: "Al-A'la", jumlahAyat: 19),
    Surah(nomor: 88, nama: "Al-Gasyiyah", jumlahAyat: 26),
    Surah(nomor: 89, nama: "Al-Fajr", jumlahAyat: 30),
    Surah(nomor: 90, nama: "Al-Balad", jumlahAyat: 20),
    Surah(nomor: 91, nama: "Asy-Syams", jumlahAyat: 15),
    Surah(nomor: 92, nama: "Al-Lail", jumlahAyat: 21),
    Surah(nomor: 93, nama: "Ad-Duha", jumlahAyat: 11),
    Surah(nomor: 94, nama: "Asy-Syarh", jumlahAyat: 8),
    Surah(nomor: 95, nama: "At-Tin", jumlahAyat: 8),
    Surah(nomor: 96, nama: "Al-'Alaq", jumlahAyat: 19),
    Surah(nomor: 97, nama: "Al-Qadr", jumlahAyat: 5),
    Surah(nomor: 98, nama: "Al-Bayyinah", jumlahAyat: 8),
    Surah(nomor: 99, nama: "Az-Zalzalah", jumlahAyat: 8),
    Surah(nomor: 100, nama: "Al-'Adiyat", jumlahAyat: 11),
    Surah(nomor: 101, nama: "Al-Qari'ah", jumlahAyat: 11),
    Surah(nomor: 102, nama: "At-Takasur", jumlahAyat: 8),
    Surah(nomor: 103, nama: "Al-'Asr", jumlahAyat: 3),
    Surah(nomor: 104, nama: "Al-Humazah", jumlahAyat: 9),
    Surah(nomor: 105, nama: "Al-Fil", jumlahAyat: 5),
    Surah(nomor: 106, nama: "Quraisy", jumlahAyat: 4),
    Surah(nomor: 107, nama: "Al-Ma'un", jumlahAyat: 7),
    Surah(nomor: 108, nama: "Al-Kausar", jumlahAyat: 3),
    Surah(nomor: 109, nama: "Al-Kafirun", jumlahAyat: 6),
    Surah(nomor: 110, nama: "An-Nasr", jumlahAyat: 3),
    Surah(nomor: 111, nama: "Al-Masad", jumlahAyat: 5),
    Surah(nomor: 112, nama: "Al-Ikhlas", jumlahAyat: 4),
    Surah(nomor: 113, nama: "Al-Falaq", jumlahAyat: 5),
    Surah(nomor: 114, nama: "An-Nas", jumlahAyat: 6),
  ];

  /// Cari objek Surah berdasarkan nama.
  static Surah? cariByNama(String? nama) {
    if (nama == null) return null;
    try {
      return daftarSurah.firstWhere((s) => s.nama == nama);
    } catch (_) {
      return null;
    }
  }

  /// Validasi nomor ayat terhadap surah tertentu.
  /// Mengembalikan null jika valid, atau pesan error jika tidak valid.
  static String? validasiAyat(String? namaSurah, int? ayat) {
    if (namaSurah == null || namaSurah.isEmpty) return null;
    if (ayat == null) return 'Nomor ayat wajib diisi.';
    if (ayat <= 0) return 'Nomor ayat harus lebih dari 0.';
    final surah = cariByNama(namaSurah);
    if (surah != null && ayat > surah.jumlahAyat) {
      return 'Nomor ayat melebihi jumlah ayat Surah ${surah.nama} (maks. ${surah.jumlahAyat}).';
    }
    return null;
  }
}
