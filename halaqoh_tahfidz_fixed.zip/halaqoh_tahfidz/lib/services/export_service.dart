import 'dart:convert';
import 'dart:io';
import 'package:csv/csv.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/setoran.dart';
import '../models/santri.dart';
import 'database_service.dart';

/// Service untuk export CSV, backup/restore JSON, dan berbagi file.
class ExportService {
  ExportService._();

  static final DateFormat _fmtTanggal = DateFormat('dd-MM-yyyy');
  static final DateFormat _fmtTanggalFile = DateFormat('yyyyMMdd');

  /// Export seluruh riwayat setoran menjadi file CSV lalu bagikan.
  static Future<void> exportCsv(List<Setoran> daftarSetoran) async {
    final db = DatabaseService.instance;
    final rows = <List<dynamic>>[
      [
        'Tanggal',
        'Nama Santri',
        'Ziyadah Dari Surah',
        'Ziyadah Dari Ayat',
        'Ziyadah Sampai Surah',
        'Ziyadah Sampai Ayat',
        'Murajaah Dari Surah',
        'Murajaah Dari Ayat',
        'Murajaah Sampai Surah',
        'Murajaah Sampai Ayat',
      ]
    ];

    for (final s in daftarSetoran) {
      final santri = db.santriById(s.santriId);
      rows.add([
        _fmtTanggal.format(s.tanggal),
        santri?.nama ?? '-',
        s.ziyadahDariSurah ?? '',
        s.ziyadahDariAyat ?? '',
        s.ziyadahSampaiSurah ?? '',
        s.ziyadahSampaiAyat ?? '',
        s.murajaahDariSurah ?? '',
        s.murajaahDariAyat ?? '',
        s.murajaahSampaiSurah ?? '',
        s.murajaahSampaiAyat ?? '',
      ]);
    }

    final csvData = const ListToCsvConverter().convert(rows);
    final dir = await getTemporaryDirectory();
    final fileName = 'rekap_halaqoh_${_fmtTanggalFile.format(DateTime.now())}.csv';
    final file = File('${dir.path}/$fileName');
    await file.writeAsString(csvData);

    await Share.shareXFiles([XFile(file.path)], text: 'Export Data Halaqoh Tahfidz');
  }

  /// Backup seluruh data (santri + setoran) ke file JSON lalu bagikan/simpan.
  static Future<File> backupData() async {
    final db = DatabaseService.instance;
    final data = {
      'aplikasi': 'Halaqoh Tahfidz - Ustadz Al Mu\'min',
      'dibuat': DateTime.now().toIso8601String(),
      'santri': db.exportSantriToMap(),
      'setoran': db.exportSetoranToMap(),
    };
    final dir = await getTemporaryDirectory();
    final fileName = 'backup_halaqoh_${_fmtTanggalFile.format(DateTime.now())}.json';
    final file = File('${dir.path}/$fileName');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    return file;
  }

  static Future<void> backupDanBagikan() async {
    final file = await backupData();
    await Share.shareXFiles([XFile(file.path)], text: 'Backup Data Halaqoh Tahfidz');
  }

  /// Restore data dari file JSON backup yang dipilih pengguna.
  static Future<void> restoreDariFile(File file) async {
    final content = await file.readAsString();
    final Map<String, dynamic> data = jsonDecode(content);
    await DatabaseService.instance.restoreFromMap(
      santriList: data['santri'] as List<dynamic>,
      setoranList: data['setoran'] as List<dynamic>,
    );
  }

  static Future<File> simpanBytesGambar(List<int> bytes, String namaFile) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$namaFile');
    await file.writeAsBytes(bytes);
    return file;
  }

  static Future<void> bagikanGambar(File file, {String? teks}) async {
    await Share.shareXFiles([XFile(file.path)], text: teks ?? 'Rekap Halaqoh Tahfidz');
  }
}
