import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/santri.dart';
import '../models/setoran.dart';

/// Service singleton untuk mengelola akses database lokal (Hive).
class DatabaseService {
  DatabaseService._internal();
  static final DatabaseService instance = DatabaseService._internal();

  static const String boxSantri = 'santriBox';
  static const String boxSetoran = 'setoranBox';

  final _uuid = const Uuid();

  Box<Santri> get santriBox => Hive.box<Santri>(boxSantri);
  Box<Setoran> get setoranBox => Hive.box<Setoran>(boxSetoran);

  /// 13 santri default sesuai data awal halaqoh.
  static const List<String> daftarSantriDefault = [
    'Amri Yusron Salim',
    'Arkan Azka',
    'Fahman Ibadurrahman',
    'Fikry Akbar',
    'Haikal Afham Permana',
    "M. Ja'far Aly",
    'M. Salman Rasyad',
    'Mikail Rasyid Riandy',
    'Muadz Abdul Malik',
    'Razka Aufa Garot',
    'Rifqi Arya Nadindra',
    'Rizki Agiliano Ramadhan',
    'Daniyal Aqila Natamihardja',
  ];

  /// Inisialisasi Hive: buka box dan registrasi adapter. Dipanggil sekali di main().
  static Future<void> init() async {
    await Hive.initFlutter();
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(SantriAdapter());
    }
    if (!Hive.isAdapterRegistered(1)) {
      Hive.registerAdapter(SetoranAdapter());
    }
    await Hive.openBox<Santri>(boxSantri);
    await Hive.openBox<Setoran>(boxSetoran);
    await instance._seedSantriDefault();
  }

  /// Mengisi 13 santri default hanya jika box santri masih kosong
  /// (pertama kali aplikasi dijalankan).
  Future<void> _seedSantriDefault() async {
    if (santriBox.isEmpty) {
      for (final nama in daftarSantriDefault) {
        final santri = Santri(id: _uuid.v4(), nama: nama);
        await santriBox.put(santri.id, santri);
      }
    }
  }

  // ---------------- SANTRI ----------------

  List<Santri> semuaSantri() {
    final list = santriBox.values.toList();
    list.sort((a, b) => a.nama.compareTo(b.nama));
    return list;
  }

  Santri? santriById(String id) => santriBox.get(id);

  Future<void> tambahSantri(String nama) async {
    final santri = Santri(id: _uuid.v4(), nama: nama.trim());
    await santriBox.put(santri.id, santri);
  }

  Future<void> editSantri(Santri santri, String namaBaru) async {
    santri.nama = namaBaru.trim();
    await santri.save();
  }

  Future<void> hapusSantri(Santri santri) async {
    // Hapus juga seluruh riwayat setoran milik santri tsb agar data konsisten.
    final setoranTerkait =
        setoranBox.values.where((s) => s.santriId == santri.id).toList();
    for (final s in setoranTerkait) {
      await s.delete();
    }
    await santri.delete();
  }

  // ---------------- SETORAN ----------------

  List<Setoran> semuaSetoran() {
    final list = setoranBox.values.toList();
    list.sort((a, b) => b.tanggal.compareTo(a.tanggal));
    return list;
  }

  Future<Setoran> tambahSetoran({
    required DateTime tanggal,
    required String santriId,
    String? ziyadahDariSurah,
    int? ziyadahDariAyat,
    String? ziyadahSampaiSurah,
    int? ziyadahSampaiAyat,
    String? murajaahDariSurah,
    int? murajaahDariAyat,
    String? murajaahSampaiSurah,
    int? murajaahSampaiAyat,
  }) async {
    final setoran = Setoran(
      id: _uuid.v4(),
      tanggal: tanggal,
      santriId: santriId,
      ziyadahDariSurah: (ziyadahDariSurah != null && ziyadahDariSurah.isNotEmpty) ? ziyadahDariSurah : null,
      ziyadahDariAyat: ziyadahDariAyat,
      ziyadahSampaiSurah: (ziyadahSampaiSurah != null && ziyadahSampaiSurah.isNotEmpty) ? ziyadahSampaiSurah : null,
      ziyadahSampaiAyat: ziyadahSampaiAyat,
      murajaahDariSurah: (murajaahDariSurah != null && murajaahDariSurah.isNotEmpty) ? murajaahDariSurah : null,
      murajaahDariAyat: murajaahDariAyat,
      murajaahSampaiSurah: (murajaahSampaiSurah != null && murajaahSampaiSurah.isNotEmpty) ? murajaahSampaiSurah : null,
      murajaahSampaiAyat: murajaahSampaiAyat,
    );
    await setoranBox.put(setoran.id, setoran);
    return setoran;
  }

  Future<void> hapusSetoran(Setoran setoran) async {
    await setoran.delete();
  }

  /// Rekap setoran dalam rentang tanggal [awal, akhir] (inklusif).
  List<Setoran> setoranDalamRentang(DateTime awal, DateTime akhir) {
    final mulai = DateTime(awal.year, awal.month, awal.day);
    final selesai = DateTime(akhir.year, akhir.month, akhir.day, 23, 59, 59);
    return setoranBox.values
        .where((s) => !s.tanggal.isBefore(mulai) && !s.tanggal.isAfter(selesai))
        .toList()
      ..sort((a, b) => a.tanggal.compareTo(b.tanggal));
  }

  List<Setoran> setoranPadaTanggal(DateTime tanggal) {
    return setoranBox.values
        .where((s) =>
            s.tanggal.year == tanggal.year &&
            s.tanggal.month == tanggal.month &&
            s.tanggal.day == tanggal.day)
        .toList();
  }

  // ---------------- BACKUP / RESTORE (dalam bentuk JSON-friendly Map) ----------------

  List<Map<String, dynamic>> exportSantriToMap() {
    return santriBox.values.map((s) => {'id': s.id, 'nama': s.nama}).toList();
  }

  List<Map<String, dynamic>> exportSetoranToMap() {
    return setoranBox.values
        .map((s) => {
              'id': s.id,
              'tanggal': s.tanggal.toIso8601String(),
              'santriId': s.santriId,
              'ziyadahDariSurah': s.ziyadahDariSurah,
              'ziyadahDariAyat': s.ziyadahDariAyat,
              'ziyadahSampaiSurah': s.ziyadahSampaiSurah,
              'ziyadahSampaiAyat': s.ziyadahSampaiAyat,
              'murajaahDariSurah': s.murajaahDariSurah,
              'murajaahDariAyat': s.murajaahDariAyat,
              'murajaahSampaiSurah': s.murajaahSampaiSurah,
              'murajaahSampaiAyat': s.murajaahSampaiAyat,
            })
        .toList();
  }

  /// Menghapus seluruh data lalu mengisi ulang dari hasil backup (restore).
  Future<void> restoreFromMap({
    required List<dynamic> santriList,
    required List<dynamic> setoranList,
  }) async {
    await santriBox.clear();
    await setoranBox.clear();

    for (final item in santriList) {
      final santri = Santri(id: item['id'] as String, nama: item['nama'] as String);
      await santriBox.put(santri.id, santri);
    }
    for (final item in setoranList) {
      final setoran = Setoran(
        id: item['id'] as String,
        tanggal: DateTime.parse(item['tanggal'] as String),
        santriId: item['santriId'] as String,
        ziyadahDariSurah: item['ziyadahDariSurah'] as String?,
        ziyadahDariAyat: item['ziyadahDariAyat'] as int?,
        ziyadahSampaiSurah: item['ziyadahSampaiSurah'] as String?,
        ziyadahSampaiAyat: item['ziyadahSampaiAyat'] as int?,
        murajaahDariSurah: item['murajaahDariSurah'] as String?,
        murajaahDariAyat: item['murajaahDariAyat'] as int?,
        murajaahSampaiSurah: item['murajaahSampaiSurah'] as String?,
        murajaahSampaiAyat: item['murajaahSampaiAyat'] as int?,
      );
      await setoranBox.put(setoran.id, setoran);
    }
  }
}
