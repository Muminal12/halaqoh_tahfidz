import 'package:flutter/material.dart';

/// Palet warna & tema aplikasi Halaqoh Tahfidz.
/// Nuansa: hijau Islami, putih, sedikit aksen emas.
class AppColors {
  AppColors._();
  static const Color hijauUtama = Color(0xFF0F6B3C);
  static const Color hijauTua = Color(0xFF0A4D2A);
  static const Color hijauMuda = Color(0xFFE7F4EC);
  static const Color emas = Color(0xFFC9A227);
  static const Color putih = Color(0xFFFFFFFF);
  static const Color abuTeks = Color(0xFF5A6B63);
  static const Color latarKartu = Color(0xFFF6FAF7);
}

ThemeData buildAppTheme() {
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: AppColors.putih,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.hijauUtama,
      primary: AppColors.hijauUtama,
      secondary: AppColors.emas,
      brightness: Brightness.light,
    ),
    fontFamily: 'Roboto',
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.hijauUtama,
      foregroundColor: AppColors.putih,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: TextStyle(
        color: AppColors.putih,
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
    ),
    cardTheme: CardThemeData(
      color: AppColors.latarKartu,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: EdgeInsets.zero,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.hijauUtama,
        foregroundColor: AppColors.putih,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.putih,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFDDE8E1)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFDDE8E1)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.hijauUtama, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: AppColors.putih,
      selectedItemColor: AppColors.hijauUtama,
      unselectedItemColor: AppColors.abuTeks,
      showUnselectedLabels: true,
      type: BottomNavigationBarType.fixed,
    ),
  );
}
