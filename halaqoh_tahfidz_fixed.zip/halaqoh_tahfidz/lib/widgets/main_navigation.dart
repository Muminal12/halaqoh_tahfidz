import 'package:flutter/material.dart';
import '../screens/dashboard_screen.dart';
import '../screens/input_setoran_screen.dart';
import '../screens/rekap_mingguan_screen.dart';
import '../screens/santri_screen.dart';
import '../screens/pengaturan_screen.dart';

/// Shell utama aplikasi dengan Bottom Navigation Bar.
class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _index = 0;

  // GlobalKey agar Dashboard bisa di-refresh dari luar (mis. setelah simpan setoran).
  final GlobalKey<DashboardScreenState> _dashboardKey = GlobalKey<DashboardScreenState>();

  void pindahKeTab(int index) {
    setState(() => _index = index);
    if (index == 0) {
      _dashboardKey.currentState?.muatUlang();
    }
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      DashboardScreen(key: _dashboardKey, onTambahSetoran: () => pindahKeTab(1)),
      InputSetoranScreen(onSelesai: () => pindahKeTab(0)),
      const RekapMingguanScreen(),
      const SantriScreen(),
      const PengaturanScreen(),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: pindahKeTab,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Beranda'),
          BottomNavigationBarItem(icon: Icon(Icons.menu_book_rounded), label: 'Setoran'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart_rounded), label: 'Rekap'),
          BottomNavigationBarItem(icon: Icon(Icons.people_alt_rounded), label: 'Santri'),
          BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: 'Pengaturan'),
        ],
      ),
    );
  }
}
