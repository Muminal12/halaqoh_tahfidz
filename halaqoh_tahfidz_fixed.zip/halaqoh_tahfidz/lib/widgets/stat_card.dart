import 'package:flutter/material.dart';
import '../theme.dart';

/// Kartu statistik kecil untuk Dashboard, contoh: "Total Santri: 13".
class StatCard extends StatelessWidget {
  final String emoji;
  final String label;
  final String value;

  const StatCard({
    super.key,
    required this.emoji,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.latarKartu,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFDDEDE3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: AppColors.hijauTua,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: AppColors.abuTeks),
          ),
        ],
      ),
    );
  }
}
