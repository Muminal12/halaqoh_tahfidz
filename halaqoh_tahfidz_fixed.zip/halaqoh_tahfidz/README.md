# Halaqoh Tahfidz

Project Flutter yang sudah dirapikan dan dilengkapi struktur Android.

Fitur utama:
- 13 santri bawaan
- Tambah/hapus santri
- Input Ziyadah dan Murajaah
- Pilihan 114 surah
- Ayat dari/sampai
- Riwayat setoran
- Rekap 7 hari
- Penyimpanan offline menggunakan SharedPreferences

## Build APK

Buka folder project dengan Flutter/Android Studio, lalu jalankan:

```bash
flutter pub get
flutter run
flutter build apk --release
```

APK release berada di `build/app/outputs/flutter-apk/app-release.apk`.

Catatan: folder Android sudah disiapkan, tetapi build tetap membutuhkan Flutter SDK dan Android SDK di komputer/lingkungan build.
